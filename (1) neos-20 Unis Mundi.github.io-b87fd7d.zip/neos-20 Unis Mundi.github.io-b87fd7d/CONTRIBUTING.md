*******************************************************
fork https://github.com/neos-20/neos-20.github.io

go to your repo....{code}green colour mai hoga 
click-> cpy link 
open git bash /wsl/linux wale apna terminal khole

->git clone {yaha link paste kare phr enter kare}

ab jo bh changes karne h kar lo
jo bh changes hue h ab usko github mai dalna h 
to 
->git status
***
->git add .
***
->git commit -m "yaha jo bh changes kiye h vo likho"
***
->git push

github mai jana apni repo mai-> pull request mai->new pull request 
fir usme neos kaa aa jayega--
fir title aur comment daal ke create pull request kar do
**Khud se merge mat karna**
******************************************************
aur kuch naya add hua h to usko apne github repo mai lane ke liye
apni github repo mai jana ....neos ka jo fork kia h usme jana ..
-->fetch upstream likh ke aa raha hoga 
usko kr dena to jo naya add hua hoga vo tumhre mai aa jayega

phr usko apne system mai lane ke liye
neos wale folder mai jake terminal kr lena
usme likhna

->git fetch origin
->git merge origin

**************************************************************

